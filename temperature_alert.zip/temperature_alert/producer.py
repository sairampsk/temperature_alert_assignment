import pika
import json
import sqlite3
from random import randint
from datetime import datetime
import time

"""This function take the message to be pushed into the queue and send it to the queue using direct exchange"""
def intiate_push(message):
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.exchange_declare(exchange='direct_logs', exchange_type='direct')

    route_key = 'check'
    channel.basic_publish(
    exchange='direct_logs', routing_key=route_key, body= json.dumps(message),)
    print(" Message sent with routing key %r and the message is %r" % (route_key, message))
    connection.close()


"""This function fetches the City names from the DB and assigns a random temperature value 
to each city and send this to the exchange process which will route the message into the queue"""

def generate_data():
    prev_time = datetime.now()
    flag = 1

# This loop runs every second to push the data to the message broker until interrupted
    while(True):
        difference = (datetime.now() - prev_time)

        """The below condition is to fetch the city details for every 5 mins from the DB"""
        if (difference.total_seconds()/60 > 5 or flag):
            flag = 0
            # establish a connection
            prev_time = datetime.now()
            conn = sqlite3.connect("TemperatureMonitor.db")
            cursor = conn.cursor()
            res = list(cursor.execute("Select city_name from cities"))
            dict ={}
            for re in res :
                dict[re[0]] = randint(30,50)

        intiate_push(dict)
        time.sleep(1)

generate_data()