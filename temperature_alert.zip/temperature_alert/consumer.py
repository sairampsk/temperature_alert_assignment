import pika
import json
from threads import createthreads

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='localhost'))
channel = connection.channel()

channel.exchange_declare(exchange='direct_logs', exchange_type='direct')
channel.queue_declare(queue='task_queue',durable=True)
queue_name = 'task_queue'


channel.queue_bind(
        exchange='direct_logs', queue='task_queue', routing_key='check')

print('Waiting for messages. To exit press CTRL+C')

"""This function will be trigger as soon as the message is pushed into the queue"""
def callback(ch, method, properties, body):
    print("Received the message with routing key %r and the message is %r" % (method.routing_key, json.loads(body)))
    createthreads(json.loads(body))


channel.basic_consume(
    queue=queue_name, on_message_callback=callback, auto_ack=True)

channel.start_consuming()

