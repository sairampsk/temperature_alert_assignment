"""This is custom module build for sending the alert notifications """
"""The print functions in the file are just to track the execution logs """

import threading
import sqlite3
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class myThread (threading.Thread):
   def __init__(self, city_name, temp):
      threading.Thread.__init__(self)
      self.city_name = city_name
      self.temp = temp
   def run(self):
      print ("Starting the thread for " + self.city_name)
      verify_temp(self.city_name, self.temp)
      print ("Exiting this thread for " + self.city_name)

def verify_temp(city_name, temp):

    if temp > 45:
        params = (city_name,)
        conn = sqlite3.connect("TemperatureMonitor.db")
        cursor = conn.cursor()
        res = cursor.execute("Select last_email_sent from cities where city_name =? ", params)
        res = (list(res)[0][0])

        fmt = '%Y-%m-%d %H:%M:%S'

        """The below condition checks whether there was any email alert sent in last one hour"""
        if (res == None) or (((datetime.now() - datetime.strptime(res, fmt)).total_seconds()/60) > 59):
            message = ("Hey, Your city %s is facing a heat wave with high temperature, stay safe!") % city_name

            sender_add = 'autobot4301@gmail.com'
            sender_pass = 'H@rdw0rk123'
            receiver_add = 'ramcherry22@gmail.com'
            msg = MIMEMultipart()
            msg['From'] = sender_add
            msg['To'] = receiver_add
            msg['Subject'] = 'This is a heat wave warning'

            msg.attach(MIMEText(message, 'plain'))

            session = smtplib.SMTP('smtp.gmail.com', 587)
            session.starttls()

            session.login(sender_add, sender_pass)
            text = msg.as_string()
            session.sendmail(sender_add, receiver_add, text)
            session.quit()
            print('Mail Sent for city ',  city_name)
            cursor.execute("Update cities set last_email_sent = datetime('now','localtime') where city_name = ?;", params)
            cursor.execute("Insert into e_log (name, temp) values (?,?);",(city_name,temp))
            conn.commit()
        conn.close()

# Create new threads
def createthreads(dict):
    tls = []
    for x in (dict.keys()):
        tobj = myThread(x, dict[x])
        tls.append(tobj)
# Start new Threads
    for x in range(len(tls)):
        tls[x].start()

    for x in range(len(tls)):
        tls[x].join()
    print("Exiting Main Thread")
