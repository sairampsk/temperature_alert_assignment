"""Run this file once as part of project installation as this file creates a DB and and the required tables
 for tracking the City wise temp monitor activity"""

import sqlite3

# establish a connection
conn = sqlite3.connect("TemperatureMonitor.db")

cursor = conn.cursor()

table_1 = """ CREATE TABLE IF NOT EXISTS cities (
city_id  INTEGER PRIMARY KEY AUTOINCREMENT, 
city_name NAME TEXT NOT NULL, 
last_email_sent  TIMESTAMP 
); """


table_2 = """ CREATE TABLE IF NOT EXISTS e_log(
                                        id integer PRIMARY KEY AUTOINCREMENT,
                                        name text NOT NULL,
                                        temp integer,
                                        email_sent timestamp DATE DEFAULT (datetime('now','localtime'))
                                    ); """

insertion = """ INSERT INTO cities(city_name) values ('Hyderabad'), ('Banglore'), ('Chennai');"""
cursor.execute(table_1)

cursor.execute(table_2)

cursor.execute(insertion)
conn.commit()
conn.close()